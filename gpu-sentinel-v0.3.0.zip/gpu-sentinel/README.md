# GPU Sentinel

**Silent data corruption detection for AI training. Catches what NVIDIA DCGM, Datadog, and W&B miss.**

`v0.2.0` — open-source, alpha. L1 anomaly + L1-MoE-Router detection live. Training Health Score + Slack/webhook reporters shipped. L2–L4 next.

## What this is

GPU Sentinel watches a PyTorch training loop and flags signs of silent data corruption — wrong-but-not-crashing GPU output. The kind of fault that makes your loss curve look weird three days later and burns hundreds of thousands of dollars in compute. Hyperscalers solve this internally and don't share the tools. proteanTecs solves it in silicon (requires SoC redesign). We solve it in the training loop.

This release ships:

- **L1 — coarse anomaly** (always-on, sub-ms/step): NaN/Inf in loss + grads, EWMA-based loss & grad-norm spike detection.
- **L1-MoE-Router** (always-on, sub-ms/step, MoE-aware): gate entropy collapse, expert load imbalance, expert starvation, per-expert grad divergence, aux-loss spike.
- **Training Health Score**: single rolling 0–1 number summarising all detector signal. Pollable. Borrowed pattern from proteanTecs' Health Index, applied at the training-loop layer.
- **Reporters**: stdout (default), Slack webhook, generic webhook. Severity-gated, rate-limited, background thread.
- **Fail-open**: every detector call wrapped so internal exceptions cannot crash a training job.

## Install

```bash
pip install gpu-sentinel              # core
pip install "gpu-sentinel[torch]"     # + PyTorch integration
```

## Two-line integration

```python
from gpu_sentinel import Monitor

monitor = Monitor()

# inside your training loop, after loss.backward():
monitor.check(model, loss)
```

## MoE-aware integration

```python
from gpu_sentinel import Monitor, L1AnomalyDetector, L1MoERouterDetector

monitor = Monitor(detectors=[L1AnomalyDetector(), L1MoERouterDetector()])

monitor.check(
    model, loss,
    router_gates=gates,
    expert_assignments=assignments,
    expert_grad_norms={"e0": n0, "e1": n1},
    aux_loss=aux,
    num_experts=num_experts,
)
```

## Training Health Score

```python
monitor.health_score    # float in [0, 1]
monitor.health_status   # "healthy" | "degraded" | "critical"
```

## Slack alerts

```python
from gpu_sentinel import Monitor, SlackReporter

monitor = Monitor(reporters=[
    SlackReporter(webhook_url="https://hooks.slack.com/services/..."),
])
```

## Try the demos

```bash
python -m gpu_sentinel.demo.inject_router_collapse   # MoE - no torch needed
python -m gpu_sentinel.demo.inject_nan               # generic L1 (needs torch)
python -m gpu_sentinel.demo.clean_run                # confirms silence on healthy
```

## Compared to

| Tool | Catches SDC? | Training-aware? | Notes |
|---|---|---|---|
| Datadog / New Relic | No | No | SaaS app observability |
| NVIDIA DCGM | Partial | Limited | Hardware health, not gradient correctness |
| Weights & Biases | No | Yes | Experiment tracking, not detection |
| V-ABFT | Yes | Selective | Production-deployed on MoE routers |
| proteanTecs | Yes | Silicon-layer | Requires SoC redesign; not for existing fleets |
| **GPU Sentinel** | **Yes** | **Yes** | **Always-on under 1%, pip-installable today** |

## Research foundation

- OCP whitepaper on SDC in AI hardware (NVIDIA, Google, Meta, Microsoft)
- Dixit et al., *Silent Data Corruptions at Scale* (Meta, 2021)
- Hochschild et al., *Cores That Don't Count* (Google, 2021)
- TU Berlin SDC survey (2026)
- proteanTecs, *Outsmarting Silent Data Corruption in AI Processors With Two-Stage Detection*

## License

MIT.

## SDC-Bench: validate the detector against your own expectations

The `gpu-sentinel` CLI ships with a reproducible fault-injection benchmark — every detection code, one command:

```bash
# Show every fault type we can inject
gpu-sentinel list-faults

# Inject one fault, see whether the detector fires
gpu-sentinel inject --fault gate-collapse --at-step 100

# Run the full SDC-Bench (all 8 fault types, summary table)
gpu-sentinel benchmark
```

Sample output from `gpu-sentinel benchmark` (live, no edits):

```
Fault                      Expected                         Detected   Latency
-------------------------- -------------------------------- ---------- ----------
nan-loss                   L1/NAN_LOSS                      YES        0 step(s)
inf-loss                   L1/INF_LOSS                      YES        0 step(s)
loss-spike                 L1/LOSS_SPIKE                    YES        0 step(s)
gate-collapse              L1/GATE_ENTROPY_COLLAPSE         YES        0 step(s)
expert-starvation          L1/EXPERT_STARVATION             YES        4 step(s)
load-imbalance             L1/EXPERT_LOAD_IMBALANCE         YES        0 step(s)
aux-loss-spike             L1/AUX_LOSS_SPIKE                YES        0 step(s)
expert-grad-divergence     L1/EXPERT_GRAD_DIVERGENCE        YES        0 step(s)

Summary:
  Detection rate:    100.0% (8/8)
  Avg latency:       0.50 step(s)
  False positives:   0 (clean)
```

For scripted runs: `--json` emits machine-readable JSON for benchmark sweeps and CI integration.

```bash
gpu-sentinel benchmark --quiet --json > sdc_bench_results.json
```
