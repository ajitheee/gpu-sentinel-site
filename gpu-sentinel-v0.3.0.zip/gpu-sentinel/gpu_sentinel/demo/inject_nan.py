"""Fault-injection demo: train tiny model, inject NaN, watch L1 fire."""
from __future__ import annotations
import sys
try:
    import torch
    import torch.nn as nn
except ImportError:
    print("[demo] PyTorch required: pip install gpu-sentinel[torch]", file=sys.stderr)
    raise SystemExit(1)
from gpu_sentinel import Monitor


def main(total_steps=300, inject_at=250, seed=0) -> int:
    torch.manual_seed(seed)
    model = nn.Sequential(nn.Linear(32, 64), nn.ReLU(), nn.Linear(64, 10))
    optim = torch.optim.SGD(model.parameters(), lr=1e-3)
    loss_fn = nn.MSELoss()
    monitor = Monitor()
    X = torch.randn(128, 32); Y = torch.randn(128, 10)
    pre = post = 0
    print(f"[demo] {inject_at} clean steps, then NaN injection", file=sys.stderr)
    for step in range(total_steps):
        if step == inject_at:
            with torch.no_grad():
                first = next(m for m in model.modules() if isinstance(m, nn.Linear))
                first.weight[0, 0] = float("nan")
            print(f"[demo] >>> NaN injected at step {step}", file=sys.stderr)
        optim.zero_grad()
        loss = loss_fn(model(X), Y)
        loss.backward()
        results = monitor.check(model, loss, step=step)
        if results:
            if step < inject_at: pre += 1
            else: post += 1
        if step != inject_at: optim.step()
        if post >= 1 and step >= inject_at + 3: break
    ok = pre == 0 and post >= 1
    print(f"[demo] pre={pre} post={post} result={'PASS' if ok else 'FAIL'}", file=sys.stderr)
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
