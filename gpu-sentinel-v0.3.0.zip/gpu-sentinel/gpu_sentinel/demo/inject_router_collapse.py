"""MoE router collapse demo - no torch required."""
from __future__ import annotations
import math, random, sys, time
from gpu_sentinel import L1AnomalyDetector, L1MoERouterDetector, Monitor


def _uniform(n, e):
    p = 1.0 / e
    return [[p] * e for _ in range(n)]


def _collapsed(n, e, target=0):
    rows = []
    for _ in range(n):
        row = [0.0] * e; row[target] = 1.0; rows.append(row)
    return rows


def main(total_steps=260, inject_at=250, seed=0) -> int:
    random.seed(seed)
    monitor = Monitor(
        detectors=[L1AnomalyDetector(), L1MoERouterDetector(warmup_steps=20)],
        heartbeat_every=50)
    print(f"[demo] simulating {total_steps} MoE steps, "
          f"injecting router collapse at step {inject_at}\n", file=sys.stderr)
    pre = post = 0
    for step in range(total_steps):
        if step < inject_at:
            gates = _uniform(32, 4)
            assignments = [random.randrange(4) for _ in range(32)]
            aux = 0.5 + random.gauss(0, 0.01)
            loss = 1.0 + 0.5 * (0.995 ** step) + random.gauss(0, 0.02)
        else:
            gates = _collapsed(32, 4, target=0)
            assignments = [0] * 32
            aux = 25.0
            loss = float("nan") if step == inject_at else 1.0
        results = monitor.check(None, loss, router_gates=gates,
                                expert_assignments=assignments, aux_loss=aux,
                                num_experts=4, step=step)
        if step == inject_at:
            print(f"\n[demo] >>> router collapsed at step {step} "
                  f"(invisible to DCGM / Datadog / W&B)\n", file=sys.stderr)
        if step < inject_at: pre += sum(1 for r in results if r.is_fault)
        else: post += sum(1 for r in results if r.is_fault)
        if step >= inject_at + 2 and post >= 1: break
    print(f"\n[demo] summary:", file=sys.stderr)
    print(f"  pre-injection faults:  {pre}  (expected 0)", file=sys.stderr)
    print(f"  post-injection faults: {post}  (expected >= 1)", file=sys.stderr)
    print(f"  health score:          {monitor.health_score:.3f}", file=sys.stderr)
    print(f"  health status:         {monitor.health_status}", file=sys.stderr)
    ok = pre == 0 and post >= 1 and monitor.health_status != "healthy"
    print(f"\n[demo] result: {'PASS - MoE router collapse detected' if ok else 'FAIL'}",
          file=sys.stderr)
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
