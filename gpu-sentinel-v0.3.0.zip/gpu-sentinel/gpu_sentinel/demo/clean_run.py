"""Clean training run - confirm detector stays silent."""
from __future__ import annotations
import sys
try:
    import torch
    import torch.nn as nn
except ImportError:
    print("[demo] PyTorch required", file=sys.stderr)
    raise SystemExit(1)
from gpu_sentinel import Monitor


def main(total_steps=300, seed=0) -> int:
    torch.manual_seed(seed)
    model = nn.Sequential(nn.Linear(32, 64), nn.ReLU(), nn.Linear(64, 10))
    optim = torch.optim.SGD(model.parameters(), lr=1e-3)
    loss_fn = nn.MSELoss()
    monitor = Monitor(heartbeat_every=100)
    X = torch.randn(128, 32); Y = torch.randn(128, 10)
    for step in range(total_steps):
        optim.zero_grad()
        loss = loss_fn(model(X), Y)
        loss.backward()
        monitor.check(model, loss, step=step)
        optim.step()
    print(f"[demo] faults_seen={monitor.faults_seen} (expected 0)", file=sys.stderr)
    return 0 if monitor.faults_seen == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
