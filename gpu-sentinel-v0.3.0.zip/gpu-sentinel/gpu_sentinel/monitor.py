"""Monitor - top-level integration surface for GPU Sentinel."""
from __future__ import annotations
from typing import Any, List, Optional
from gpu_sentinel.detectors.base import DetectionResult, Severity
from gpu_sentinel.detectors.l1_anomaly import L1AnomalyDetector
from gpu_sentinel.health import HealthScore, HealthSnapshot
from gpu_sentinel.reporters.stdout import StdoutReporter
from gpu_sentinel.safety import fail_open


class Monitor:
    """High-level monitor. ``verbose`` gates heartbeats only;
    fault events always dispatch to all reporters (so Slack still fires
    when stdout is silenced)."""

    def __init__(self, *, detectors: Optional[List[Any]] = None,
                 reporter: Optional[Any] = None,
                 reporters: Optional[List[Any]] = None,
                 heartbeat_every: int = 100, verbose: bool = True) -> None:
        self.detectors = detectors if detectors is not None else [L1AnomalyDetector()]
        if reporters is not None:
            self.reporters: List[Any] = list(reporters)
        elif reporter is not None:
            self.reporters = [reporter]
        else:
            self.reporters = [StdoutReporter()]
        self.heartbeat_every = heartbeat_every
        self.verbose = verbose
        self._step = 0
        self._faults_seen = 0
        self._monitored_params = 0
        self._health = HealthScore()

    @property
    def step(self) -> int: return self._step
    @property
    def faults_seen(self) -> int: return self._faults_seen
    @property
    def health_score(self) -> float: return self._health.score
    @property
    def health_status(self) -> str: return self._health.status
    def health_snapshot(self) -> HealthSnapshot: return self._health.snapshot()
    @property
    def reporter(self) -> Any:
        return self.reporters[0] if self.reporters else None
    def add_reporter(self, r: Any) -> None: self.reporters.append(r)

    def _dispatch(self, result: DetectionResult) -> None:
        for rep in self.reporters:
            try: rep.emit(result)
            except Exception: pass

    def _dispatch_all(self, results: List[DetectionResult]) -> None:
        for rep in self.reporters:
            try: rep.emit_all(results)
            except Exception: pass

    def _emit_heartbeat(self, step: int, monitored_params: int) -> None:
        if not self.verbose: return
        for rep in self.reporters:
            es = getattr(rep, "emit_status", None)
            if callable(es):
                try: es(step=step, monitored_params=monitored_params)
                except Exception: pass

    def reset(self) -> None:
        for d in self.detectors:
            try: d.reset()
            except Exception: pass
        self._step = 0
        self._faults_seen = 0
        self._health.reset()

    @fail_open
    def check(self, model=None, loss=None, *, step=None, **kwargs) -> List[DetectionResult]:
        cur_step = step if step is not None else self._step
        if model is not None:
            named = getattr(model, "named_parameters", None)
            if callable(named):
                try:
                    self._monitored_params = sum(1 for _ in named())
                except Exception:
                    pass
        all_results: List[DetectionResult] = []
        for d in self.detectors:
            try:
                res = d.check(model=model, loss=loss, step=cur_step, **kwargs)
            except Exception as exc:
                self._dispatch(DetectionResult(
                    layer=getattr(d, "layer", "?"),
                    detector=getattr(d, "name", type(d).__name__),
                    severity=Severity.WARNING,
                    code="DETECTOR_ERROR",
                    message=f"detector raised {type(exc).__name__}: {exc}",
                    step=cur_step))
                continue
            all_results.extend(res or [])
        self._dispatch_all(all_results)
        for r in all_results:
            if r.is_fault: self._faults_seen += 1
        self._health.update(all_results)
        self._step = cur_step + 1
        if (self.heartbeat_every > 0
                and self._step % self.heartbeat_every == 0
                and not all_results):
            self._emit_heartbeat(self._step, self._monitored_params)
        return all_results
