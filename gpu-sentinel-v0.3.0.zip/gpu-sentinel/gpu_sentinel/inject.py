"""Fault injection library + simulated-training harness for SDC-Bench.

Used by the CLI (`gpu-sentinel inject ...`) to produce reproducible
detection results for a single fault type, or by the benchmark command
(`gpu-sentinel benchmark`) to sweep every fault type at once.

Each fault type maps to one detection code we ship today. Adding a new
fault means: add an entry to FAULT_TYPES, add the injection callback,
and add the expected-detector-code mapping for the report.
"""
from __future__ import annotations

import math
import random
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

from gpu_sentinel.detectors.base import DetectionResult, Severity
from gpu_sentinel.detectors.l1_anomaly import L1AnomalyDetector
from gpu_sentinel.detectors.l1_moe_router import L1MoERouterDetector
from gpu_sentinel.monitor import Monitor


# ============================================================
# Fault type registry
# ============================================================

@dataclass
class FaultSpec:
    name: str
    description: str
    targets_detector: str        # human-readable expected detector code
    is_moe_specific: bool = False


FAULT_TYPES: Dict[str, FaultSpec] = {
    "nan-loss": FaultSpec(
        "nan-loss",
        "Inject NaN into the loss value at the target step.",
        "L1/NAN_LOSS",
    ),
    "inf-loss": FaultSpec(
        "inf-loss",
        "Inject Inf into the loss value at the target step.",
        "L1/INF_LOSS",
    ),
    "loss-spike": FaultSpec(
        "loss-spike",
        "Multiply loss by 1000x for one step (simulates exponent bit-flip).",
        "L1/LOSS_SPIKE",
    ),
    "gate-collapse": FaultSpec(
        "gate-collapse",
        "Collapse MoE router gates to route all tokens to one expert.",
        "L1/GATE_ENTROPY_COLLAPSE",
        is_moe_specific=True,
    ),
    "expert-starvation": FaultSpec(
        "expert-starvation",
        "Stop routing any tokens to a specific expert (for --duration steps).",
        "L1/EXPERT_STARVATION",
        is_moe_specific=True,
    ),
    "load-imbalance": FaultSpec(
        "load-imbalance",
        "Skew expert routing to highly unbalanced distribution.",
        "L1/EXPERT_LOAD_IMBALANCE",
        is_moe_specific=True,
    ),
    "aux-loss-spike": FaultSpec(
        "aux-loss-spike",
        "Spike the MoE load-balancing aux loss by 50x.",
        "L1/AUX_LOSS_SPIKE",
        is_moe_specific=True,
    ),
    "expert-grad-divergence": FaultSpec(
        "expert-grad-divergence",
        "Diverge one expert's gradient norm to 100x baseline.",
        "L1/EXPERT_GRAD_DIVERGENCE",
        is_moe_specific=True,
    ),
}


# ============================================================
# Simulated-training helpers (no torch dependency)
# ============================================================

def _uniform_gates(n_tokens: int, n_experts: int):
    p = 1.0 / n_experts
    return [[p] * n_experts for _ in range(n_tokens)]


def _collapsed_gates(n_tokens: int, n_experts: int, target: int = 0):
    rows = []
    for _ in range(n_tokens):
        row = [0.0] * n_experts
        row[target] = 1.0
        rows.append(row)
    return rows


def _skewed_gates(n_tokens: int, n_experts: int, rng: random.Random, skew: float = 0.9):
    """Most probability mass concentrated on expert 0, rest distributed thin."""
    rest = (1.0 - skew) / (n_experts - 1)
    rows = []
    for _ in range(n_tokens):
        row = [rest] * n_experts
        row[0] = skew
        rows.append(row)
    return rows


def _balanced_assignments(n_tokens: int, n_experts: int, rng: random.Random):
    return [rng.randrange(n_experts) for _ in range(n_tokens)]


def _imbalanced_assignments(n_tokens: int, n_experts: int, target_share: float = 0.85):
    """Most tokens to expert 0, rest scattered."""
    n_to_zero = int(n_tokens * target_share)
    out = [0] * n_to_zero
    for i in range(n_tokens - n_to_zero):
        out.append(1 + (i % max(1, n_experts - 1)))
    return out


# ============================================================
# Injection result
# ============================================================

@dataclass
class InjectionResult:
    fault: str
    injected_at_step: int
    total_steps: int
    num_experts: int
    detected: bool
    detected_at_step: Optional[int]
    latency_steps: Optional[int]
    detectors_fired: List[str] = field(default_factory=list)
    pre_fault_faults: int = 0
    health_score: float = 1.0
    health_status: str = "healthy"
    expected_detector: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "fault": self.fault,
            "expected_detector": self.expected_detector,
            "injected_at_step": self.injected_at_step,
            "total_steps": self.total_steps,
            "num_experts": self.num_experts,
            "detected": self.detected,
            "detected_at_step": self.detected_at_step,
            "latency_steps": self.latency_steps,
            "detectors_fired": self.detectors_fired,
            "pre_fault_faults": self.pre_fault_faults,
            "health_score": round(self.health_score, 4),
            "health_status": self.health_status,
        }


# ============================================================
# Single-fault runner (used by `inject` CLI command)
# ============================================================

def run_injection(
    fault: str,
    *,
    at_step: int = 100,
    total_steps: int = 200,
    num_experts: int = 4,
    n_tokens: int = 32,
    duration: int = 8,
    warmup_steps: int = 20,
    seed: int = 0,
    verbose_monitor: bool = True,
) -> InjectionResult:
    """Run a simulated training trace and inject one fault at the target step.

    Returns an InjectionResult summarizing whether the detector fired.
    """
    if fault not in FAULT_TYPES:
        raise ValueError(f"unknown fault type: {fault!r} (try `gpu-sentinel list-faults`)")
    spec = FAULT_TYPES[fault]
    if at_step >= total_steps:
        total_steps = at_step + duration + 5
    if at_step < warmup_steps:
        raise ValueError(
            f"at_step ({at_step}) must be >= warmup_steps ({warmup_steps}) "
            "or detectors will not have a baseline yet"
        )

    rng = random.Random(seed)
    monitor = Monitor(
        detectors=[
            L1AnomalyDetector(),
            L1MoERouterDetector(warmup_steps=warmup_steps),
        ],
        verbose=verbose_monitor,
    )

    pre_faults = 0
    detected_at: Optional[int] = None
    fired: List[str] = []
    fault_active_until = at_step + duration  # for sustained faults

    for step in range(total_steps):
        # Default healthy training-step signals
        gates = _uniform_gates(n_tokens, num_experts)
        assignments = _balanced_assignments(n_tokens, num_experts, rng)
        aux = 0.5 + rng.gauss(0, 0.01)
        loss = 1.0 + 0.5 * (0.995 ** step) + rng.gauss(0, 0.02)
        expert_grads = {f"e{i}": 0.3 + rng.gauss(0, 0.02) for i in range(num_experts)}

        # Apply fault if we're in the injection window
        in_window = at_step <= step < fault_active_until
        if in_window:
            if fault == "nan-loss" and step == at_step:
                loss = float("nan")
            elif fault == "inf-loss" and step == at_step:
                loss = float("inf")
            elif fault == "loss-spike" and step == at_step:
                loss = loss * 1000.0
            elif fault == "gate-collapse":
                gates = _collapsed_gates(n_tokens, num_experts, target=0)
                assignments = [0] * n_tokens
                aux = 25.0
            elif fault == "expert-starvation":
                # all tokens go to expert 0, expert 1 starves
                assignments = [(0 if rng.random() < 0.5 else 2) for _ in range(n_tokens)]
            elif fault == "load-imbalance":
                gates = _skewed_gates(n_tokens, num_experts, rng, skew=0.9)
                assignments = _imbalanced_assignments(n_tokens, num_experts, 0.9)
            elif fault == "aux-loss-spike" and step == at_step:
                aux = 25.0
            elif fault == "expert-grad-divergence" and step == at_step:
                expert_grads["e2"] = 30.0

        results = monitor.check(
            None, loss,
            router_gates=gates,
            expert_assignments=assignments,
            expert_grad_norms=expert_grads,
            aux_loss=aux,
            num_experts=num_experts,
            step=step,
        )

        if step < at_step:
            pre_faults += sum(1 for r in results if r.is_fault)
        else:
            for r in results:
                if r.is_fault:
                    code = f"{r.layer}/{r.code}"
                    if code not in fired:
                        fired.append(code)
                    if detected_at is None:
                        detected_at = step

        # Stop early once we've confirmed detection a few steps past the fault
        if detected_at is not None and step >= at_step + 3:
            break

    return InjectionResult(
        fault=fault,
        injected_at_step=at_step,
        total_steps=total_steps,
        num_experts=num_experts,
        detected=detected_at is not None,
        detected_at_step=detected_at,
        latency_steps=(detected_at - at_step) if detected_at is not None else None,
        detectors_fired=fired,
        pre_fault_faults=pre_faults,
        health_score=monitor.health_score,
        health_status=monitor.health_status,
        expected_detector=spec.targets_detector,
    )


# ============================================================
# Benchmark runner (used by `benchmark` CLI command)
# ============================================================

@dataclass
class BenchmarkResult:
    per_fault: List[InjectionResult]
    detection_rate: float
    avg_latency: Optional[float]
    pre_fault_total: int

    def to_dict(self) -> Dict[str, Any]:
        return {
            "detection_rate": round(self.detection_rate, 4),
            "avg_latency_steps": round(self.avg_latency, 2) if self.avg_latency is not None else None,
            "pre_fault_false_positives_total": self.pre_fault_total,
            "per_fault": [r.to_dict() for r in self.per_fault],
        }


def run_benchmark(
    *,
    at_step: int = 100,
    total_steps: int = 200,
    num_experts: int = 4,
    seed: int = 0,
    verbose_monitor: bool = False,
) -> BenchmarkResult:
    """Run every fault type once and aggregate detection stats."""
    results: List[InjectionResult] = []
    for fault_name in FAULT_TYPES.keys():
        res = run_injection(
            fault_name,
            at_step=at_step,
            total_steps=total_steps,
            num_experts=num_experts,
            seed=seed,
            verbose_monitor=verbose_monitor,
        )
        results.append(res)

    detected = sum(1 for r in results if r.detected)
    rate = detected / len(results) if results else 0.0
    latencies = [r.latency_steps for r in results if r.latency_steps is not None]
    avg_latency = (sum(latencies) / len(latencies)) if latencies else None
    pre_total = sum(r.pre_fault_faults for r in results)

    return BenchmarkResult(
        per_fault=results,
        detection_rate=rate,
        avg_latency=avg_latency,
        pre_fault_total=pre_total,
    )
