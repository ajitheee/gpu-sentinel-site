"""Command-line interface for GPU Sentinel.

Entry points:

    gpu-sentinel list-faults
    gpu-sentinel inject --fault FAULT [--at-step N] [--num-experts N] [--seed N]
    gpu-sentinel benchmark
    gpu-sentinel version

Designed so a customer can validate the detector against their own
expectations in one command, with no Python knowledge required beyond
``pip install gpu-sentinel``.
"""
from __future__ import annotations

import argparse
import json
import sys
from typing import List, Optional

from gpu_sentinel import __version__
from gpu_sentinel.inject import (
    BenchmarkResult,
    FAULT_TYPES,
    InjectionResult,
    run_benchmark,
    run_injection,
)


# ============================================================
# Pretty-print helpers
# ============================================================

def _color_enabled() -> bool:
    import os
    return sys.stderr.isatty() and os.environ.get("GPU_SENTINEL_COLOR", "1") != "0"


def _c(s: str, code: str) -> str:
    if not _color_enabled():
        return s
    return f"\033[{code}m{s}\033[0m"


def _green(s: str) -> str: return _c(s, "32")
def _red(s: str) -> str: return _c(s, "31")
def _yellow(s: str) -> str: return _c(s, "33")
def _cyan(s: str) -> str: return _c(s, "36")
def _bold(s: str) -> str: return _c(s, "1")


# ============================================================
# Sub-command: list-faults
# ============================================================

def cmd_list_faults(args: argparse.Namespace) -> int:
    if getattr(args, "json", False):
        out = {
            name: {
                "description": spec.description,
                "expected_detector": spec.targets_detector,
                "is_moe_specific": spec.is_moe_specific,
            }
            for name, spec in FAULT_TYPES.items()
        }
        print(json.dumps(out, indent=2))
        return 0

    print(_bold("Available fault types:"))
    print()
    width = max(len(n) for n in FAULT_TYPES) + 2
    for name, spec in FAULT_TYPES.items():
        tag = _yellow("[MoE]") if spec.is_moe_specific else "     "
        print(f"  {tag} {_cyan(name.ljust(width))}  {spec.description}")
        print(f"        {'':<{width}}  expected detector: {spec.targets_detector}")
        print()
    return 0


# ============================================================
# Sub-command: inject
# ============================================================

def _print_injection(res: InjectionResult, args: argparse.Namespace) -> None:
    if getattr(args, "json", False):
        print(json.dumps(res.to_dict(), indent=2))
        return

    print()
    print(_bold("=" * 60))
    sym = _green("YES") if res.detected else _red("NO")
    print(f"  Result:           {sym}")
    print(f"  Fault:            {res.fault}")
    print(f"  Expected:         {res.expected_detector}")
    print(f"  Injected at step: {res.injected_at_step}")
    print(f"  Detected at step: {res.detected_at_step}")
    lat = "n/a" if res.latency_steps is None else f"{res.latency_steps} step(s)"
    print(f"  Latency:          {lat}")
    print(f"  Pre-fault faults: {res.pre_fault_faults} "
          f"({_green('clean baseline') if res.pre_fault_faults == 0 else _red('FALSE POSITIVES')})")
    if res.detectors_fired:
        print(f"  Detectors fired:")
        for code in res.detectors_fired:
            print(f"    - {_cyan(code)}")
    print(f"  Health score:     {res.health_score:.3f} "
          f"({res.health_status})")
    print(_bold("=" * 60))


def cmd_inject(args: argparse.Namespace) -> int:
    if args.fault not in FAULT_TYPES:
        print(_red(f"ERROR: unknown fault {args.fault!r}"), file=sys.stderr)
        print(f"Run `gpu-sentinel list-faults` for valid options.", file=sys.stderr)
        return 2

    if not args.quiet and not args.json:
        print(f"[gpu-sentinel inject] fault={args.fault} "
              f"at_step={args.at_step} num_experts={args.num_experts} "
              f"seed={args.seed}", file=sys.stderr)

    res = run_injection(
        args.fault,
        at_step=args.at_step,
        total_steps=args.total_steps,
        num_experts=args.num_experts,
        seed=args.seed,
        verbose_monitor=(not args.quiet) and (not args.json),
    )
    _print_injection(res, args)
    return 0 if res.detected and res.pre_fault_faults == 0 else 1


# ============================================================
# Sub-command: benchmark
# ============================================================

def _print_benchmark(result: BenchmarkResult, args: argparse.Namespace) -> None:
    if getattr(args, "json", False):
        print(json.dumps(result.to_dict(), indent=2))
        return

    print()
    print(_bold("SDC-Bench results:"))
    print()
    print(f"  {'Fault':<26} {'Expected':<32} {'Detected':<10} {'Latency':<10}")
    print(f"  {'-' * 26} {'-' * 32} {'-' * 10} {'-' * 10}")
    for r in result.per_fault:
        sym = _green("YES") if r.detected else _red("NO ")
        lat = "-" if r.latency_steps is None else f"{r.latency_steps} step(s)"
        print(f"  {r.fault:<26} {r.expected_detector:<32} {sym:<10} {lat:<10}")
    print()
    print(_bold("Summary:"))
    print(f"  Detection rate:    {_green(f'{result.detection_rate * 100:.1f}%')} "
          f"({sum(1 for r in result.per_fault if r.detected)}/{len(result.per_fault)})")
    if result.avg_latency is not None:
        print(f"  Avg latency:       {result.avg_latency:.2f} step(s)")
    fp_status = _green("0 (clean)") if result.pre_fault_total == 0 \
        else _red(f"{result.pre_fault_total}")
    print(f"  False positives:   {fp_status}")
    print()


def cmd_benchmark(args: argparse.Namespace) -> int:
    if not args.quiet and not args.json:
        print(f"[gpu-sentinel benchmark] running {len(FAULT_TYPES)} fault types...",
              file=sys.stderr)
    result = run_benchmark(
        at_step=args.at_step,
        total_steps=args.total_steps,
        num_experts=args.num_experts,
        seed=args.seed,
        verbose_monitor=False,
    )
    _print_benchmark(result, args)
    # Exit 0 only if all detected and zero pre-fault FPs
    all_detected = all(r.detected for r in result.per_fault)
    return 0 if all_detected and result.pre_fault_total == 0 else 1


# ============================================================
# Argument parser
# ============================================================

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="gpu-sentinel",
        description=("GPU Sentinel CLI - silent data corruption detection for AI training. "
                     "Use `inject` to validate one fault type, or `benchmark` for SDC-Bench."),
    )
    parser.add_argument("--version", action="version", version=f"gpu-sentinel {__version__}")
    sub = parser.add_subparsers(dest="command", required=True)

    # list-faults
    p_list = sub.add_parser("list-faults", help="show all supported fault types")
    p_list.add_argument("--json", action="store_true", help="emit machine-readable JSON")
    p_list.set_defaults(func=cmd_list_faults)

    # inject
    p_inj = sub.add_parser("inject", help="inject one fault and report whether detected")
    p_inj.add_argument("--fault", required=True,
                       help=f"fault type (one of: {', '.join(FAULT_TYPES.keys())})")
    p_inj.add_argument("--at-step", type=int, default=100,
                       help="training step to inject at (must be >= warmup, default 100)")
    p_inj.add_argument("--total-steps", type=int, default=200,
                       help="total simulation steps (default 200)")
    p_inj.add_argument("--num-experts", type=int, default=4,
                       help="number of MoE experts (default 4)")
    p_inj.add_argument("--seed", type=int, default=0, help="random seed (default 0)")
    p_inj.add_argument("--quiet", action="store_true",
                       help="suppress monitor heartbeats and progress chatter")
    p_inj.add_argument("--json", action="store_true",
                       help="emit machine-readable JSON result")
    p_inj.set_defaults(func=cmd_inject)

    # benchmark
    p_b = sub.add_parser("benchmark", help="run SDC-Bench: every fault, detection table")
    p_b.add_argument("--at-step", type=int, default=100)
    p_b.add_argument("--total-steps", type=int, default=200)
    p_b.add_argument("--num-experts", type=int, default=4)
    p_b.add_argument("--seed", type=int, default=0)
    p_b.add_argument("--quiet", action="store_true")
    p_b.add_argument("--json", action="store_true")
    p_b.set_defaults(func=cmd_benchmark)

    return parser


def main(argv: Optional[List[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
