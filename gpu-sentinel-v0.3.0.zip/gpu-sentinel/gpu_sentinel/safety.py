"""Fail-open safety wrapper. GPU Sentinel must NEVER crash a training job."""
from __future__ import annotations
import functools, logging, os
from typing import Any, Callable, TypeVar

F = TypeVar("F", bound=Callable[..., Any])
log = logging.getLogger("gpu_sentinel.safety")
_STRICT_MODE = os.environ.get("GPU_SENTINEL_STRICT", "0") == "1"

def fail_open(func: F) -> F:
    @functools.wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        try:
            return func(*args, **kwargs)
        except Exception as exc:
            if _STRICT_MODE:
                raise
            log.warning("gpu_sentinel internal error in %s: %s (training continues)",
                        func.__qualname__, exc)
            return None
    return wrapper  # type: ignore[return-value]

def is_strict() -> bool:
    return _STRICT_MODE
