"""L1-MoE-Router - sub-millisecond MoE-specific anomaly detection."""
from __future__ import annotations
import math
from typing import Any, Dict, List, Optional, Sequence
from gpu_sentinel.detectors.base import BaseDetector, DetectionResult, Severity
from gpu_sentinel.detectors.l1_anomaly import _EWMA, _to_float


def _gate_entropy(gates):
    if gates is None:
        return None
    if hasattr(gates, "shape") and hasattr(gates, "log") and hasattr(gates, "sum"):
        try:
            shape = tuple(gates.shape)
            if len(shape) < 2 or shape[-1] < 2:
                return None
            clamped = gates.clamp(min=1e-12) if hasattr(gates, "clamp") else gates
            per_token = -(clamped * clamped.log()).sum(dim=-1)
            return float(per_token.mean().item())
        except Exception:
            return None
    try:
        rows = list(gates)
        if not rows or not hasattr(rows[0], "__iter__"):
            return None
        n = len(rows)
        total = 0.0
        for row in rows:
            for p in row:
                if p > 0:
                    total -= p * math.log(max(p, 1e-12))
        return total / n if n > 0 else None
    except Exception:
        return None


def _expert_token_counts(assignments, num_experts):
    if assignments is None:
        return None
    flat = []
    try:
        if hasattr(assignments, "tolist"):
            data = assignments.tolist()
        else:
            data = assignments
        for item in data:
            if isinstance(item, (list, tuple)):
                for x in item:
                    flat.append(int(x))
            else:
                flat.append(int(item))
    except Exception:
        return None
    if not flat:
        return None
    if num_experts is None:
        num_experts = max(flat) + 1
    counts = [0] * num_experts
    for idx in flat:
        if 0 <= idx < num_experts:
            counts[idx] += 1
    return counts


def _coef_variation(counts):
    if not counts:
        return None
    n = len(counts)
    mean = sum(counts) / n
    if mean <= 0:
        return None
    var = sum((c - mean) ** 2 for c in counts) / n
    return math.sqrt(var) / mean


class L1MoERouterDetector(BaseDetector):
    layer = "L1"
    name = "L1MoERouterDetector"

    def __init__(self, *, warmup_steps=30, entropy_sigma=5.0, load_cv_sigma=6.0,
                 expert_grad_sigma=6.0, aux_loss_sigma=6.0,
                 starvation_threshold_steps=5) -> None:
        super().__init__()
        self.warmup_steps = warmup_steps
        self.entropy_sigma = entropy_sigma
        self.load_cv_sigma = load_cv_sigma
        self.expert_grad_sigma = expert_grad_sigma
        self.aux_loss_sigma = aux_loss_sigma
        self.starvation_threshold_steps = starvation_threshold_steps
        self._entropy_ewma = _EWMA(alpha=0.05)
        self._cv_ewma = _EWMA(alpha=0.05)
        self._aux_loss_ewma = _EWMA(alpha=0.05)
        self._per_expert_grad: Dict[Any, _EWMA] = {}
        self._zero_streak: Dict[int, int] = {}

    def reset(self) -> None:
        super().reset()
        self._entropy_ewma = _EWMA(alpha=0.05)
        self._cv_ewma = _EWMA(alpha=0.05)
        self._aux_loss_ewma = _EWMA(alpha=0.05)
        self._per_expert_grad = {}
        self._zero_streak = {}

    def check(self, *, model=None, loss=None, step=None, router_gates=None,
              expert_assignments=None, expert_grad_norms=None, aux_loss=None,
              num_experts=None, **kwargs) -> List[DetectionResult]:
        results: List[DetectionResult] = []
        cur_step = step if step is not None else self._step
        self._step = cur_step + 1

        if router_gates is None and expert_assignments is None and \
           expert_grad_norms is None and aux_loss is None:
            return results

        # 1. Gate entropy collapse
        entropy = _gate_entropy(router_gates)
        if entropy is not None and math.isfinite(entropy):
            if cur_step >= self.warmup_steps and entropy < 0.05:
                results.append(DetectionResult(self.layer, self.name, Severity.ALERT,
                    "GATE_ENTROPY_COLLAPSE",
                    f"router gate entropy collapsed at step {cur_step}: entropy={entropy:.4g}",
                    cur_step, {"entropy": entropy}))
            elif self._entropy_ewma.is_anomaly(entropy, sigma=self.entropy_sigma):
                if self._entropy_ewma.mean is not None and entropy < self._entropy_ewma.mean:
                    results.append(DetectionResult(self.layer, self.name, Severity.WARNING,
                        "GATE_ENTROPY_DROP",
                        f"router gate entropy dropped at step {cur_step}",
                        cur_step, {"entropy": entropy}))
            self._entropy_ewma.update(entropy)

        # 2. Expert load + starvation
        counts = _expert_token_counts(expert_assignments, num_experts)
        if counts is not None and len(counts) >= 2:
            for idx, c in enumerate(counts):
                if c == 0:
                    self._zero_streak[idx] = self._zero_streak.get(idx, 0) + 1
                else:
                    self._zero_streak[idx] = 0
            starved = [idx for idx, s in self._zero_streak.items()
                       if s >= self.starvation_threshold_steps]
            if starved and cur_step >= self.warmup_steps:
                results.append(DetectionResult(self.layer, self.name, Severity.WARNING,
                    "EXPERT_STARVATION",
                    f"expert(s) {starved} starved for {self.starvation_threshold_steps}+ steps (step {cur_step})",
                    cur_step, {"starved_experts": starved}))

            cv = _coef_variation(counts)
            if cv is not None and math.isfinite(cv):
                if self._cv_ewma.is_anomaly(cv, sigma=self.load_cv_sigma):
                    if self._cv_ewma.mean is not None and cv > self._cv_ewma.mean:
                        results.append(DetectionResult(self.layer, self.name, Severity.WARNING,
                            "EXPERT_LOAD_IMBALANCE",
                            f"expert load imbalance at step {cur_step}: cv={cv:.4g} baseline_mean={self._cv_ewma.mean:.4g}",
                            cur_step, {"cv": cv}))
                self._cv_ewma.update(cv)

        # 3. Per-expert grad divergence
        if expert_grad_norms:
            for expert_id, norm in expert_grad_norms.items():
                norm_val = _to_float(norm)
                if norm_val is None or not math.isfinite(norm_val):
                    continue
                ewma = self._per_expert_grad.setdefault(expert_id, _EWMA(alpha=0.05))
                if ewma.is_anomaly(norm_val, sigma=self.expert_grad_sigma):
                    results.append(DetectionResult(self.layer, self.name, Severity.WARNING,
                        "EXPERT_GRAD_DIVERGENCE",
                        f"expert {expert_id!r} grad norm diverged at step {cur_step}: value={norm_val:.4g}",
                        cur_step, {"expert_id": expert_id, "grad_norm": norm_val}))
                ewma.update(norm_val)

        # 4. Aux-loss spike
        aux_val = _to_float(aux_loss)
        if aux_val is not None and math.isfinite(aux_val):
            if self._aux_loss_ewma.is_anomaly(aux_val, sigma=self.aux_loss_sigma):
                if self._aux_loss_ewma.mean is not None and aux_val > self._aux_loss_ewma.mean:
                    results.append(DetectionResult(self.layer, self.name, Severity.WARNING,
                        "AUX_LOSS_SPIKE",
                        f"MoE aux-loss spike at step {cur_step}: value={aux_val:.4g} baseline_mean={self._aux_loss_ewma.mean:.4g}",
                        cur_step, {"aux_loss": aux_val}))
            self._aux_loss_ewma.update(aux_val)

        return results
