"""L1 coarse anomaly detector - always-on, sub-millisecond per step."""
from __future__ import annotations
import math
from typing import Any, List, Optional
from gpu_sentinel.detectors.base import BaseDetector, DetectionResult, Severity


def _to_float(x: Any) -> Optional[float]:
    if x is None:
        return None
    item = getattr(x, "item", None)
    if callable(item):
        try:
            return float(item())
        except Exception:
            return None
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


def _iter_grad_norms(model: Any):
    if model is None:
        return
    named = getattr(model, "named_parameters", None)
    if not callable(named):
        return
    for name, param in named():
        grad = getattr(param, "grad", None)
        if grad is None:
            continue
        norm_fn = getattr(grad, "norm", None)
        if not callable(norm_fn):
            continue
        try:
            norm_val = _to_float(norm_fn())
        except Exception:
            continue
        if norm_val is None:
            continue
        yield name, norm_val, grad


def _has_nan_or_inf(tensor: Any):
    has_nan = has_inf = False
    isnan_fn = getattr(tensor, "isnan", None)
    isinf_fn = getattr(tensor, "isinf", None)
    if callable(isnan_fn):
        try:
            has_nan = bool(isnan_fn().any().item())
        except Exception:
            pass
    if callable(isinf_fn):
        try:
            has_inf = bool(isinf_fn().any().item())
        except Exception:
            pass
    return has_nan, has_inf


class _EWMA:
    def __init__(self, alpha: float = 0.05) -> None:
        self.alpha = alpha
        self.mean: Optional[float] = None
        self.var: float = 0.0
        self.n: int = 0

    def update(self, x: float) -> None:
        if self.mean is None:
            self.mean = x
        else:
            delta = x - self.mean
            self.mean = self.mean + self.alpha * delta
            self.var = (1 - self.alpha) * (self.var + self.alpha * delta * delta)
        self.n += 1

    def std(self) -> float:
        return math.sqrt(self.var) if self.var > 0 else 0.0

    def is_anomaly(self, x: float, sigma: float = 8.0) -> bool:
        if self.mean is None or self.n < 20:
            return False
        s = self.std()
        if s <= 0:
            return False
        return abs(x - self.mean) > sigma * s


class L1AnomalyDetector(BaseDetector):
    layer = "L1"
    name = "L1AnomalyDetector"

    def __init__(self, *, warmup_steps: int = 20, grad_norm_sigma: float = 8.0,
                 loss_sigma: float = 8.0) -> None:
        super().__init__()
        self.warmup_steps = warmup_steps
        self.grad_norm_sigma = grad_norm_sigma
        self.loss_sigma = loss_sigma
        self._loss_ewma = _EWMA(alpha=0.05)
        self._grad_norm_ewma = _EWMA(alpha=0.05)

    def reset(self) -> None:
        super().reset()
        self._loss_ewma = _EWMA(alpha=0.05)
        self._grad_norm_ewma = _EWMA(alpha=0.05)

    def check(self, *, model=None, loss=None, step=None, **kwargs) -> List[DetectionResult]:
        results: List[DetectionResult] = []
        cur_step = step if step is not None else self._step
        self._step = cur_step + 1

        loss_val = _to_float(loss)
        if loss_val is not None:
            if math.isnan(loss_val):
                results.append(DetectionResult(self.layer, self.name, Severity.ALERT,
                    "NAN_LOSS", f"loss is NaN at step {cur_step}", cur_step,
                    {"loss": loss_val}))
            elif math.isinf(loss_val):
                results.append(DetectionResult(self.layer, self.name, Severity.ALERT,
                    "INF_LOSS", f"loss is Inf at step {cur_step}", cur_step,
                    {"loss": loss_val}))
            else:
                if self._loss_ewma.is_anomaly(loss_val, sigma=self.loss_sigma):
                    results.append(DetectionResult(self.layer, self.name, Severity.WARNING,
                        "LOSS_SPIKE",
                        f"loss spike at step {cur_step}: value={loss_val:.4g} baseline_mean={self._loss_ewma.mean:.4g}",
                        cur_step, {"loss": loss_val, "baseline_mean": self._loss_ewma.mean}))
                self._loss_ewma.update(loss_val)

        total_sq = 0.0
        any_grad = False
        nan_params: list = []
        inf_params: list = []
        for name, norm_val, grad in _iter_grad_norms(model):
            any_grad = True
            total_sq += norm_val * norm_val
            has_nan, has_inf = _has_nan_or_inf(grad)
            if has_nan:
                nan_params.append(name)
            if has_inf:
                inf_params.append(name)

        if nan_params:
            results.append(DetectionResult(self.layer, self.name, Severity.ALERT,
                "NAN_GRAD",
                f"NaN in gradients at step {cur_step}, {len(nan_params)} parameter(s) affected",
                cur_step, {"params_sample": nan_params[:5]}))
        if inf_params:
            results.append(DetectionResult(self.layer, self.name, Severity.ALERT,
                "INF_GRAD",
                f"Inf in gradients at step {cur_step}, {len(inf_params)} parameter(s) affected",
                cur_step, {"params_sample": inf_params[:5]}))

        if any_grad:
            total_norm = math.sqrt(total_sq)
            if math.isfinite(total_norm):
                if self._grad_norm_ewma.is_anomaly(total_norm, sigma=self.grad_norm_sigma):
                    results.append(DetectionResult(self.layer, self.name, Severity.WARNING,
                        "GRAD_NORM_SPIKE",
                        f"gradient norm spike at step {cur_step}: value={total_norm:.4g}",
                        cur_step, {"grad_norm": total_norm}))
                self._grad_norm_ewma.update(total_norm)

        return results
