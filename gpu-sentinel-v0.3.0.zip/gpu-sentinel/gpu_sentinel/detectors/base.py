"""Detector base classes and shared types."""
from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


class Severity(str, Enum):
    INFO = "info"
    WARNING = "warning"
    ALERT = "alert"


@dataclass
class DetectionResult:
    layer: str
    detector: str
    severity: Severity
    code: str
    message: str
    step: Optional[int] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    @property
    def is_fault(self) -> bool:
        return self.severity in (Severity.WARNING, Severity.ALERT)


class BaseDetector:
    layer: str = "Lx"
    name: str = "BaseDetector"

    def __init__(self) -> None:
        self._step: int = 0

    def reset(self) -> None:
        self._step = 0

    def check(self, *, model: Any = None, loss: Any = None,
              step: Optional[int] = None, **kwargs: Any) -> List[DetectionResult]:
        raise NotImplementedError
