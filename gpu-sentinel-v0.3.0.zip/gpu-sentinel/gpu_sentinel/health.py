"""Training Health Score - single 0..1 number that summarizes detector signal."""
from __future__ import annotations
from dataclasses import dataclass
from typing import Iterable, List
from gpu_sentinel.detectors.base import DetectionResult, Severity


_SEVERITY_PENALTY = {Severity.INFO: 0.0, Severity.WARNING: 0.05, Severity.ALERT: 0.25}
_DEFAULT_RECOVERY = 0.005
HEALTHY_THRESHOLD = 0.85
DEGRADED_THRESHOLD = 0.50


@dataclass
class HealthSnapshot:
    score: float
    status: str
    faults_in_window: int


class HealthScore:
    def __init__(self, *, starting_score: float = 1.0,
                 recovery_per_step: float = _DEFAULT_RECOVERY) -> None:
        self._score = max(0.0, min(1.0, starting_score))
        self._recovery_per_step = recovery_per_step
        self._recent_faults: List[str] = []
        self._window_size = 100

    def update(self, results: Iterable[DetectionResult]) -> None:
        results_list = list(results)
        penalty = 0.0
        for r in results_list:
            penalty += _SEVERITY_PENALTY.get(r.severity, 0.0)
            if r.is_fault:
                self._recent_faults.append(r.code)
        if len(self._recent_faults) > self._window_size:
            self._recent_faults = self._recent_faults[-self._window_size:]
        self._score = max(0.0, self._score - penalty)
        self._score = min(1.0, self._score + self._recovery_per_step)

    @property
    def score(self) -> float:
        return self._score

    @property
    def status(self) -> str:
        if self._score >= HEALTHY_THRESHOLD: return "healthy"
        if self._score >= DEGRADED_THRESHOLD: return "degraded"
        return "critical"

    @property
    def faults_in_window(self) -> int:
        return len(self._recent_faults)

    def snapshot(self) -> HealthSnapshot:
        return HealthSnapshot(self._score, self.status, self.faults_in_window)

    def reset(self) -> None:
        self._score = 1.0
        self._recent_faults = []
