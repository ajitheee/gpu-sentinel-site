"""Webhook + Slack reporters - background thread, rate-limited, severity-gated."""
from __future__ import annotations
import json, logging, os, queue, threading, time
import urllib.error, urllib.request
from typing import Any, Dict, List, Optional
from gpu_sentinel.detectors.base import DetectionResult, Severity

log = logging.getLogger("gpu_sentinel.reporters.webhook")
_SEVERITY_ORDER = {Severity.INFO: 0, Severity.WARNING: 1, Severity.ALERT: 2}


def _severity_at_least(sev: Severity, minimum: Severity) -> bool:
    return _SEVERITY_ORDER.get(sev, 0) >= _SEVERITY_ORDER.get(minimum, 0)


class WebhookReporter:
    def __init__(self, url: str, *, headers: Optional[Dict[str, str]] = None,
                 min_severity: Severity = Severity.WARNING,
                 rate_limit_per_min: int = 30, timeout_sec: float = 4.0,
                 prefix: str = "gpu_sentinel") -> None:
        self.url = url
        self.headers = {"Content-Type": "application/json", **(headers or {})}
        self.min_severity = min_severity
        self.rate_limit_per_min = max(0, rate_limit_per_min)
        self.timeout_sec = timeout_sec
        self.prefix = prefix
        self._send_times: List[float] = []
        self._lock = threading.Lock()
        self._queue: "queue.Queue[Dict[str, Any]]" = queue.Queue(maxsize=1024)
        self._worker: Optional[threading.Thread] = None
        self._stopped = False
        self._start_worker()

    def _start_worker(self) -> None:
        if self._worker is None or not self._worker.is_alive():
            t = threading.Thread(target=self._run, daemon=True,
                                 name=f"{self.prefix}-webhook")
            t.start()
            self._worker = t

    def _run(self) -> None:
        while not self._stopped:
            try:
                payload = self._queue.get(timeout=1.0)
            except queue.Empty:
                continue
            if payload is None:
                break
            self._post(payload)
            self._queue.task_done()

    def stop(self, timeout: float = 2.0) -> None:
        self._stopped = True
        try:
            self._queue.put_nowait(None)
        except queue.Full:
            pass
        if self._worker is not None:
            self._worker.join(timeout=timeout)

    def _allowed_now(self) -> bool:
        if self.rate_limit_per_min <= 0:
            return True
        now = time.time()
        with self._lock:
            self._send_times = [t for t in self._send_times if now - t < 60.0]
            if len(self._send_times) >= self.rate_limit_per_min:
                return False
            self._send_times.append(now)
            return True

    def _format_payload(self, result: DetectionResult) -> Dict[str, Any]:
        return {"service": self.prefix, "layer": result.layer,
                "detector": result.detector, "severity": result.severity.value,
                "code": result.code, "message": result.message,
                "step": result.step, "metadata": result.metadata}

    def emit(self, result: DetectionResult) -> None:
        try:
            if not _severity_at_least(result.severity, self.min_severity):
                return
            if not self._allowed_now():
                return
            payload = self._format_payload(result)
            try:
                self._queue.put_nowait(payload)
            except queue.Full:
                log.warning("gpu_sentinel webhook queue full")
        except Exception as exc:
            log.warning("gpu_sentinel webhook.emit suppressed %s", exc)

    def emit_all(self, results: List[DetectionResult]) -> None:
        for r in results:
            self.emit(r)

    def _post(self, payload: Dict[str, Any]) -> None:
        try:
            body = json.dumps(payload).encode("utf-8")
            req = urllib.request.Request(self.url, data=body,
                                          headers=self.headers, method="POST")
            with urllib.request.urlopen(req, timeout=self.timeout_sec) as resp:
                resp.read()
        except Exception as exc:
            log.warning("gpu_sentinel webhook POST failed: %s", exc)


_SLACK_ICONS = {Severity.INFO: ":information_source:",
                Severity.WARNING: ":warning:",
                Severity.ALERT: ":rotating_light:"}
_SLACK_COLORS = {Severity.INFO: "#36a64f",
                 Severity.WARNING: "#daa520",
                 Severity.ALERT: "#c84b1e"}


class SlackReporter(WebhookReporter):
    def __init__(self, webhook_url: str, *, username: str = "GPU Sentinel",
                 channel: Optional[str] = None,
                 min_severity: Severity = Severity.WARNING,
                 rate_limit_per_min: int = 30) -> None:
        super().__init__(url=webhook_url, min_severity=min_severity,
                         rate_limit_per_min=rate_limit_per_min)
        self.username = username
        self.channel = channel

    def _format_payload(self, result: DetectionResult) -> Dict[str, Any]:
        icon = _SLACK_ICONS.get(result.severity, "")
        color = _SLACK_COLORS.get(result.severity, "#999999")
        text = f"{icon} *{result.severity.value.upper()}* `{result.code}` - {result.message}"
        attachment = {"color": color, "fields": [
            {"title": "Layer", "value": result.layer, "short": True},
            {"title": "Step", "value": str(result.step), "short": True},
            {"title": "Detector", "value": result.detector, "short": False}],
            "footer": "gpu_sentinel", "ts": int(time.time())}
        payload = {"text": text, "username": self.username,
                   "attachments": [attachment]}
        if self.channel:
            payload["channel"] = self.channel
        return payload


def slack_from_env(env_var: str = "GPU_SENTINEL_SLACK_WEBHOOK",
                    **kwargs: Any) -> Optional[SlackReporter]:
    url = os.environ.get(env_var, "").strip()
    if not url:
        return None
    return SlackReporter(webhook_url=url, **kwargs)
