"""Stdout reporter - one line per event, severity-tagged."""
from __future__ import annotations
import os, sys, time
from typing import List
from gpu_sentinel.detectors.base import DetectionResult, Severity

_USE_COLOR = sys.stderr.isatty() and os.environ.get("GPU_SENTINEL_COLOR", "1") != "0"
_COLORS = {Severity.INFO: "\033[36m", Severity.WARNING: "\033[33m", Severity.ALERT: "\033[31m"}
_RESET = "\033[0m"


def _c(sev: Severity, text: str) -> str:
    return f"{_COLORS.get(sev, '')}{text}{_RESET}" if _USE_COLOR else text


class StdoutReporter:
    def __init__(self, *, prefix: str = "gpu_sentinel") -> None:
        self.prefix = prefix

    def emit(self, result: DetectionResult) -> None:
        ts = time.strftime("%H:%M:%S")
        sev = result.severity.value.upper()
        line = f"[{ts}] {self.prefix} {sev:<7} {result.layer}/{result.code:<22} {result.message}"
        print(_c(result.severity, line), file=sys.stderr, flush=True)

    def emit_all(self, results: List[DetectionResult]) -> None:
        for r in results:
            self.emit(r)

    def emit_status(self, step: int, monitored_params: int) -> None:
        ts = time.strftime("%H:%M:%S")
        line = f"[{ts}] {self.prefix} INFO    L1/HEARTBEAT              step={step} params_monitored={monitored_params} (no anomalies)"
        print(_c(Severity.INFO, line), file=sys.stderr, flush=True)
