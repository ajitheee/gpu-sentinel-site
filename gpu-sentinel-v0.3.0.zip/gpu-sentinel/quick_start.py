"""Minimal copy-paste integration example."""
import torch
import torch.nn as nn
from gpu_sentinel import Monitor

model = nn.Sequential(nn.Linear(32, 64), nn.ReLU(), nn.Linear(64, 10))
optim = torch.optim.SGD(model.parameters(), lr=1e-3)
loss_fn = nn.MSELoss()
X = torch.randn(64, 32); Y = torch.randn(64, 10)

monitor = Monitor()   # <-- two lines
for step in range(200):
    optim.zero_grad()
    loss = loss_fn(model(X), Y)
    loss.backward()
    monitor.check(model, loss)   # <-- two lines
    optim.step()
