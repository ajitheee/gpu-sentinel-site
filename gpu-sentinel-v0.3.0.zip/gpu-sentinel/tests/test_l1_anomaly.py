import pytest
from gpu_sentinel import L1AnomalyDetector, Monitor


def test_nan_loss():
    r = L1AnomalyDetector().check(loss=float("nan"), step=0)
    assert "NAN_LOSS" in {x.code for x in r}


def test_inf_loss():
    r = L1AnomalyDetector().check(loss=float("inf"), step=0)
    assert "INF_LOSS" in {x.code for x in r}


def test_monitor_never_crashes():
    m = Monitor(verbose=False)
    m.check(None, None)
    m.check(model="garbage", loss="garbage")
    m.check(None, float("nan"))
