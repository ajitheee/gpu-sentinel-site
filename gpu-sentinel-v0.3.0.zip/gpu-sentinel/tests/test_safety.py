from gpu_sentinel.safety import fail_open


def test_returns_value():
    @fail_open
    def f(): return 42
    assert f() == 42


def test_swallows_exceptions():
    @fail_open
    def boom(): raise RuntimeError("x")
    assert boom() is None
