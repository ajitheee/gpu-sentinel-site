from gpu_sentinel import HealthScore, Monitor, Severity
from gpu_sentinel.detectors.base import DetectionResult


def test_starts_healthy():
    h = HealthScore()
    assert h.score == 1.0 and h.status == "healthy"


def test_alert_reduces():
    h = HealthScore()
    h.update([DetectionResult("L1", "t", Severity.ALERT, "X", "m")])
    assert h.score < 1.0


def test_critical():
    h = HealthScore()
    for _ in range(10):
        h.update([DetectionResult("L1", "t", Severity.ALERT, "X", "m")])
    assert h.status == "critical"


def test_monitor_health():
    m = Monitor(verbose=False)
    assert m.health_score == 1.0
    m.check(None, float("nan"))
    assert m.health_score < 1.0
