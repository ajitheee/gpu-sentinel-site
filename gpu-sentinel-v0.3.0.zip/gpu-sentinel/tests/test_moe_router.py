import math, random
from gpu_sentinel import L1MoERouterDetector, Severity


def _uni(n, e):
    p = 1.0 / e
    return [[p] * e for _ in range(n)]


def _coll(n, e, t=0):
    rows = []
    for _ in range(n):
        row = [0.0] * e; row[t] = 1.0; rows.append(row)
    return rows


def test_noop_without_signals():
    assert L1MoERouterDetector().check(loss=1.0, step=0) == []


def test_entropy_collapse():
    d = L1MoERouterDetector(warmup_steps=5)
    for s in range(20):
        d.check(router_gates=_uni(64, 8), step=s)
    r = d.check(router_gates=_coll(64, 8, 0), step=20)
    sevs = {x.code: x.severity for x in r}
    assert "GATE_ENTROPY_COLLAPSE" in sevs
    assert sevs["GATE_ENTROPY_COLLAPSE"] == Severity.ALERT


def test_clean_no_false_positives():
    d = L1MoERouterDetector(warmup_steps=20)
    faults = 0
    for s in range(300):
        random.seed(s)
        asg = [random.randrange(4) for _ in range(32)]
        r = d.check(router_gates=_uni(32, 4), expert_assignments=asg,
                    aux_loss=0.5 + 0.01 * math.sin(s/5), step=s)
        faults += sum(1 for x in r if x.is_fault)
    assert faults == 0


def test_aux_spike():
    d = L1MoERouterDetector(warmup_steps=20, aux_loss_sigma=4.0)
    random.seed(1)
    for s in range(80):
        d.check(aux_loss=0.5 + random.gauss(0, 0.01), step=s)
    r = d.check(aux_loss=50.0, step=80)
    assert "AUX_LOSS_SPIKE" in {x.code for x in r}
