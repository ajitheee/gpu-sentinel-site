import time
from gpu_sentinel import SlackReporter, WebhookReporter, Severity
from gpu_sentinel.detectors.base import DetectionResult


def _cap(cls=WebhookReporter, **kw):
    cap = []
    class C(cls):
        def _post(self, p): cap.append(p)
    return C("http://x.test/", **kw), cap


def _wait(r, t=2.0):
    end = time.time() + t
    while time.time() < end and not r._queue.empty():
        time.sleep(0.01)
    time.sleep(0.1)


def _ev(s=Severity.ALERT, c="X"):
    return DetectionResult("L1", "d", s, c, "m", step=5, metadata={})


def test_emits_alert():
    r, cap = _cap(min_severity=Severity.WARNING)
    r.emit(_ev(Severity.ALERT, "NAN_LOSS"))
    _wait(r); r.stop()
    assert len(cap) == 1 and cap[0]["code"] == "NAN_LOSS"


def test_severity_gate():
    r, cap = _cap(min_severity=Severity.ALERT)
    r.emit(_ev(Severity.WARNING))
    _wait(r); r.stop()
    assert cap == []


def test_rate_limit():
    r, cap = _cap(min_severity=Severity.WARNING, rate_limit_per_min=3)
    for i in range(10):
        r.emit(_ev(Severity.ALERT, f"E{i}"))
    _wait(r); r.stop()
    assert len(cap) == 3


def test_slack_payload():
    cap = []
    class CS(SlackReporter):
        def _post(self, p): cap.append(p)
    r = CS("http://x.test/", username="test-bot")
    r.emit(_ev(Severity.ALERT, "NAN_GRAD"))
    _wait(r); r.stop()
    assert cap[0]["username"] == "test-bot"
    assert "NAN_GRAD" in cap[0]["text"]
